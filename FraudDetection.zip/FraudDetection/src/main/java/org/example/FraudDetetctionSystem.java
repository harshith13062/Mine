package org.example;

import java.util.Objects;

public class FraudDetetctionSystem {

    public Boolean processTransaction(final Transaction transaction){
        if(Objects.isNull(transaction)){
            System.out.println("Not a valid Scenario");
        }
        DetectFraud detectFraud1 = new VelocityRuleCheck();
        DetectFraud detectFraud2 = new AccountCheck();
        if(!detectFraud2.checkRule(transaction) || !detectFraud1.checkRule(transaction)){
            return false;
        }
        return true;
    }
}
