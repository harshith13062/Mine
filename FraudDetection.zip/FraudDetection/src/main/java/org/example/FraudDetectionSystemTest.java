package org.example;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;

import static junit.framework.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class FraudDetectionSystemTest {

    @Mock DetectFraud detectFraud;
    @Mock VelocityRuleCheck velocityRuleCheck;
    @Mock AccountCheck accountCheck;
    @InjectMocks FraudDetetctionSystem fraudDetetctionSystem;

    @Test
    void testFraudDetectionWithBlackListedAccount() {
        final Transaction transaction = new Transaction("abc123", 6000.0, "Bnagalore", "Samsung", new Date());
        final Boolean result = fraudDetetctionSystem.processTransaction(transaction);
        assertTrue(result);
    }

}
