package org.example;

import java.util.Date;
import java.util.List;


public class Transaction {

    private String userId;
    private Double amount;
    private String location;
    private String deviceId;
    private Date dateOfTransaction;
    private List<Transaction>  previousTransactions;

    public Transaction(String userId, Double amount, String location, String deviceId, Date dateOfTransaction){
        this.userId = userId;
        this.amount = amount;
        this.location = location;
        this.deviceId = deviceId;
        this.dateOfTransaction= dateOfTransaction;
    }

    public void setPreviousTransactions(List<Transaction> previousTransactions) {
        this.previousTransactions = previousTransactions;
    }

    public List<Transaction> getPreviousTransactions(){
        return this.previousTransactions;
    }

    public Date getDateOfTransaction() {
        return this.dateOfTransaction;
    }

    public Double getAmount() {
        return this.amount;
    }

    public String getUserId() {
        return this.userId;
    }
}
