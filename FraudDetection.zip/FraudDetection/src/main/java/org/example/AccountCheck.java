package org.example;


import java.util.List;
import java.util.Objects;

public class AccountCheck implements DetectFraud{

    public static Double maxCapLimitForBlackListedUsers = 5000.0;
    public static List<String> blackListedUsers = List.of("abc","abc1","abc2");
    @Override
    public Boolean checkRule(Transaction transaction){

        if(Objects.nonNull(transaction.getAmount())){
            System.out.println("amount cannot be null");
        }
        if(blackListedUsers.isEmpty()){
            return true;
        }
        if(transaction.getAmount().compareTo(maxCapLimitForBlackListedUsers)>0 && blackListedUsers.contains(transaction.getUserId())){
            return false;
        }
        return true;
    }
}
