package org.example;

import java.util.Date;
import java.util.List;

public class VelocityRuleCheck implements DetectFraud{

    public static long timeIntervalInSeconds = 30;
    public static Double maxTransactionCap = 2000.0;
    @Override
    public Boolean checkRule(Transaction transaction){
        List<Transaction> previousTransactions = transaction.getPreviousTransactions();
        int n = previousTransactions.size();
        if(n==0){
            return true;
        }
        final Date lastDate = previousTransactions.get(n-1).getDateOfTransaction();
        final Date currentDate = transaction.getDateOfTransaction();
        long diffInTime = currentDate.getTime() - lastDate.getTime();
        long difference_In_Seconds = (diffInTime / 1000) % 60;
        if(difference_In_Seconds < timeIntervalInSeconds && (transaction.getAmount().compareTo(maxTransactionCap) > 0)){
            return false;
        }
        return true;
     }
}
