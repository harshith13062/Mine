package org.example;

public interface DetectFraud {
    public Boolean checkRule(Transaction transaction);
}
