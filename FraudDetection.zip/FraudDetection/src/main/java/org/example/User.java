package org.example;

public class User {

    private String id;
    private String userName;
    private String password;
}
