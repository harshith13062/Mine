package org.example;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import org.example.Transaction;

public class Main {
    public static void main(String[] args) {
        int i = 0;
        List<Transaction> previousTransactions = new ArrayList<>();
        while(i<4) {
            Scanner scanner = new Scanner(System.in);
            String userId = scanner.next();
            String location = scanner.next();
            Double amount = scanner.nextDouble();
            String deviceId = scanner.next();
            Date dateOfTransaction = new Date();
            Transaction transaction = new Transaction(userId, amount, location, deviceId, dateOfTransaction);
            previousTransactions.add(transaction);
            i++;
        }
        Scanner scanner = new Scanner(System.in);
        String userId = scanner.next();
        String location = scanner.next();
        Double amount = scanner.nextDouble();
        String deviceId = scanner.next();
        Date dateOfTransaction = new Date();
        Transaction transaction1 = new Transaction(userId, amount, location, deviceId, dateOfTransaction);
        transaction1.setPreviousTransactions(previousTransactions);
        final FraudDetetctionSystem fraudDetetctionSystem = new FraudDetetctionSystem();
        final Boolean isNotFraud = fraudDetetctionSystem.processTransaction(transaction1);
        if(isNotFraud){
            System.out.println("This is a legitimate transaction");
        }
        else{
            System.out.println("This is a fraud transaction");
        }
    }
}